//
//  DevMateHelper.swift
//  IPLocation
//
//  Created by Valentino Urbano on 26/06/15.
//  Copyright (c) 2015 Valentino Urbano. All rights reserved.
//

import Foundation
